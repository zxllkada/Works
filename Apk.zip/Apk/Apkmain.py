from kivymd.app import MDApp
from kivy.base import Builder
from kivy.core.window import Window

#Window.size = (580, 1100)


class m(MDApp):
    def build(self):
        return Builder.load_string("""
NavigationLayout:
	id: nav_layout
	ScreenManager:
		id: screen_manager
		Screen:
			name: "MENU"
			
			MDBoxLayout:
				orientation: 'horizontal'
				padding: dp(7)
				size_hint: 1, 0.1
				pos_hint: {"top": 1}
				md_bg_color:  (0.949, 0.949, 0.949, 1)
				
				MDIconButton:
					icon: "menu"
					pos_hint: {"left": 1, "center_y": .5}
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					on_press: nav_drawer.set_state("open")
					
				MDLabel:
					text: "Menu"
					font_name: "theboldfont.ttf"
					pos_hint: {"center_x": .5, "center_y": .45}
					padding: [15, 0]
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					
				MDIconButton:
					icon: "view-carousel"
					pos_hint: {"right": 1, "center_y": .5}
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					on_release:
						app.root.ids.screen_manager.transition.direction = "down"
						app.root.ids.screen_manager.current = "GALLERY"
					        
				MDIconButton:
					icon: "dots-vertical"
					pos_hint: {"right": 1, "center_y": .5}
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					on_release:
						app.root.ids.screen_manager.transition.direction = "left"
						app.root.ids.screen_manager.current = "SETTINGS"
						
			ScrollView:
				size_hint: 1, 0.9
				
				MDGridLayout:
					orientation: "vertical"
					size_hint_y : None
					height: self.minimum_height + 1965
					cols: 2
					padding: dp(10)
					spacing: 20
					md_bg_color:  (0.604, 0.675, 0.773, 0.2)
					
						
					FitImage:
						source: "IMG_1.jpg"
						height: self.minimum_height
					
					FitImage:
						source: "IMG_2.jpg"
						height: self.minimum_height
							
					FitImage:
						source: "IMG_3.jpg"
						height: self.minimum_height
						
					FitImage:
						source: "IMG_4.jpg"
						height: self.minimum_height
						
					FitImage:
						source: "IMG_1.jpg"
						height: self.minimum_height
					
					FitImage:
						source: "IMG_2.jpg"
						height: self.minimum_height
							
					FitImage:
						source: "IMG_3.jpg"
						height: self.minimum_height
						
					FitImage:
						source: "IMG_4.jpg"
						height: self.minimum_height
					FitImage:
						source: "IMG_1.jpg"
						height: self.minimum_height
					
					FitImage:
						source: "IMG_2.jpg"
						height: self.minimum_height
							
					FitImage:
						source: "IMG_3.jpg"
						height: self.minimum_height
						
					FitImage:
						source: "IMG_4.jpg"
						height: self.minimum_height
					
		Screen:
			name: "SETTINGS"
			
			MDBoxLayout:
				orientation: 'horizontal'
				padding: dp(7)
				size_hint: 1, 0.1
				pos_hint: {"top": 1}
				md_bg_color:  (0.949, 0.949, 0.949, 1)
				
				MDIconButton:
					icon: "keyboard-backspace"
					pos_hint: {"left": 1, "center_y": .5}
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					on_release:
						app.root.ids.screen_manager.transition.direction = "right"
						app.root.ids.screen_manager.current = "MENU"
						
				MDLabel:
					text: "SETTINGS"
					font_name: "theboldfont.ttf"
					pos_hint: {"left": 1, "center_y": .45}
					padding: [15, 0]
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					
				MDIconButton:
					icon: "professional-hexagon"
					pos_hint: {"right": 1, "center_y": .5}
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					
			ScrollView:
				size_hint: 1, 0.9
				
				MDGridLayout:
					orientation: "vertical"
					size_hint_y : None
					height: self.minimum_height + 800
					cols: 1
					padding: dp(10)
					spacing: 20
					md_bg_color:  (0.604, 0.675, 0.773, 0.2)
					
					MDLabel:
						text: "MEMBERSHIP : Free"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "LANGUAGE : English"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "USERNAME : Kada Soulayman"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "MEMBERSHIP CODE : 52465432"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "Facebook Link: https://www.facebook.com/zxlll"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
					
					MDLabel:
						text: "MEMBERSHIP : Free"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "LANGUAGE : English"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "USERNAME : Kada Soulayman"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "MEMBERSHIP CODE : 52465432"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "Facebook Link: https://www.facebook.com/zxlll"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					
					MDSeparator:
						
					MDLabel:
						text: "Facebook Link: https://www.facebook.com/zxlll"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
					
					MDLabel:
						text: "MEMBERSHIP : Free"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "LANGUAGE : English"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "USERNAME : Kada Soulayman"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "MEMBERSHIP CODE : 52465432"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "Facebook Link: https://www.facebook.com/zxlll"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
						
					MDSeparator:
						
					MDLabel:
						text: "Facebook Link: https://www.facebook.com/zxlll"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
					
					MDLabel:
						text: "MEMBERSHIP : Free"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "LANGUAGE : English"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "USERNAME : Kada Soulayman"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "MEMBERSHIP CODE : 52465432"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
					MDSeparator:
						
					MDLabel:
						text: "Facebook Link: https://www.facebook.com/zxlll"
						font_name: "SinkinSans-400Regular.ttf"
						font_size: "10sp"
						theme_text_color: "Custom"
						text_color: (0, 0, 0, 1)
						
		Screen:
			name: "GALLERY"
			
			MDBoxLayout:
				orientation: 'horizontal'
				padding: dp(7)
				size_hint: 1, 0.1
				pos_hint: {"top": 1}
				md_bg_color:  (0.949, 0.949, 0.949, 1)
				
				MDIconButton:
					icon: "keyboard-backspace"
					pos_hint: {"left": 1, "center_y": .5}
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					on_release:
						app.root.ids.screen_manager.transition.direction = "right"
						app.root.ids.screen_manager.current = "MENU"
						
				MDLabel:
					text: "GALLERY"
					font_name: "theboldfont.ttf"
					pos_hint: {"left": 1, "center_y": .45}
					padding: [15, 0]
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
			
		Screen:
			name: "LAST_NEWS"
			
			MDBoxLayout:
				orientation: 'horizontal'
				padding: dp(7)
				size_hint: 1, 0.1
				pos_hint: {"top": 1}
				md_bg_color:  (0.949, 0.949, 0.949, 1)
				
				MDIconButton:
					icon: "keyboard-backspace"
					pos_hint: {"left": 1, "center_y": .5}
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					on_release:
						app.root.ids.screen_manager.transition.direction = "right"
						app.root.ids.screen_manager.current = "MENU"
						
				MDLabel:
					text: "LAST NEWS"
					font_name: "theboldfont.ttf"
					pos_hint: {"left": 1, "center_y": .45}
					padding: [15, 0]
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					
		Screen:
			name: "CONTACT_WITH_ME"
			
			MDBoxLayout:
				orientation: 'horizontal'
				padding: dp(7)
				size_hint: 1, 0.1
				pos_hint: {"top": 1}
				md_bg_color:  (0.949, 0.949, 0.949, 1)
				
				MDIconButton:
					icon: "keyboard-backspace"
					pos_hint: {"left": 1, "center_y": .5}
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					on_release:
						app.root.ids.screen_manager.transition.direction = "right"
						app.root.ids.screen_manager.current = "MENU"
						
				MDLabel:
					text: "CONTACT WITH ME"
					font_name: "theboldfont.ttf"
					pos_hint: {"left": 1, "center_y": .45}
					padding: [15, 0]
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					
		Screen:
			name: "SMART_SHARE"
			
			MDBoxLayout:
				orientation: 'horizontal'
				padding: dp(7)
				size_hint: 1, 0.1
				pos_hint: {"top": 1}
				md_bg_color:  (0.949, 0.949, 0.949, 1)
				
				MDIconButton:
					icon: "keyboard-backspace"
					pos_hint: {"left": 1, "center_y": .5}
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					on_release:
						app.root.ids.screen_manager.transition.direction = "right"
						app.root.ids.screen_manager.current = "MENU"
						
				MDLabel:
					text: "SMART SHARE"
					font_name: "theboldfont.ttf"
					pos_hint: {"left": 1, "center_y": .45}
					padding: [15, 0]
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					
		Screen:
			name: "ABOUT"
			
			MDBoxLayout:
				orientation: 'horizontal'
				padding: dp(7)
				size_hint: 1, 0.1
				pos_hint: {"top": 1}
				md_bg_color:  (0.949, 0.949, 0.949, 1)
				
				MDIconButton:
					icon: "keyboard-backspace"
					pos_hint: {"left": 1, "center_y": .5}
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					on_release:
						app.root.ids.screen_manager.transition.direction = "right"
						app.root.ids.screen_manager.current = "MENU"
						
				MDLabel:
					text: "ABOUT"
					font_name: "theboldfont.ttf"
					pos_hint: {"left": 1, "center_y": .45}
					padding: [15, 0]
					theme_text_color: "Custom"
					text_color: (0.376, 0.376, 0.376, 1)
					
			MDBoxLayout:
				orientation: "vertical"
				size_hint: 1, 0.9
				md_bg_color:  (0.604, 0.675, 0.773, 0.2)
					
				MDLabel:
					text: "Hi There, Copyrhits ©"
					font_name: "SinkinSans-400Regular.ttf"
					font_size: "10sp"
					theme_text_color: "Custom"
					text_color: (0, 0, 0, 1)
					size_hint: 1, 1
					
					
			
	MDNavigationDrawer:
		id: nav_drawer
		swipe_distance: 10
		
		
		MDBoxLayout:
			orientation: 'vertical'
			size_hint: 1, 1
			md_bg_color:  (0.949, 0.949, 0.949, 1)

			MDBoxLayout:
				size_hint: 1, .383
				canvas.before:	
					Rectangle:
						size: self.size
						pos: self.pos
						source: "Car.jpg"
					
			ScrollView:

				MDList:
					OneLineIconListItem:
						text: "Home"
						on_press:
							app.root.ids.nav_drawer.set_state("close")
							app.root.ids.screen_manager.transition.direction = "left"
							app.root.ids.screen_manager.current = "MENU"
						IconLeftWidget:
							icon: "home-outline"
						
					OneLineIconListItem:
						text: "Last News"
						on_press:
							app.root.ids.nav_drawer.set_state("close")
							app.root.ids.screen_manager.transition.direction = "left"
							app.root.ids.screen_manager.current = "LAST_NEWS"
						IconLeftWidget:
							icon: "newspaper-variant-multiple"
										
					OneLineIconListItem:
						text: "Contact With Me"
						on_press:
							app.root.ids.nav_drawer.set_state("close")
							app.root.ids.screen_manager.transition.direction = "left"
							app.root.ids.screen_manager.current = "CONTACT_WITH_ME"
						IconLeftWidget:
							icon: "email-variant"
								
					OneLineIconListItem:
						text: "Smart Share"
						on_press:
							app.root.ids.nav_drawer.set_state("close")
							app.root.ids.screen_manager.transition.direction = "left"
							app.root.ids.screen_manager.current = "SMART_SHARE"
						IconLeftWidget:
							icon: "share-variant"
								
					OneLineIconListItem:
						text: "About"
						on_press:
							app.root.ids.nav_drawer.set_state("close")
							app.root.ids.screen_manager.transition.direction = "left"
							app.root.ids.screen_manager.current = "ABOUT"
						IconLeftWidget:
							icon: "information-outline"
								
        """)

m().run()